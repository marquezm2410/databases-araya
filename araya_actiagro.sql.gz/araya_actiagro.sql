-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: araya_actiagro
-- ------------------------------------------------------
-- Server version	5.7.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acuiferos`
--

DROP TABLE IF EXISTS `acuiferos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acuiferos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `region_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `acuifero_unique` (`nombre`,`region_id`),
  KEY `FK_acuiferos_1` (`region_id`),
  CONSTRAINT `FK_acuiferos_1` FOREIGN KEY (`region_id`) REFERENCES `regiones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acuiferos`
--

LOCK TABLES `acuiferos` WRITE;
/*!40000 ALTER TABLE `acuiferos` DISABLE KEYS */;
INSERT INTO `acuiferos` (`id`, `nombre`, `region_id`, `created_at`, `updated_at`) VALUES (1,'Acuífero Elqui',4,'2020-07-13 21:25:32','2020-07-13 21:25:32'),(2,'Acuífero Limarí',4,'2020-07-13 21:25:49','2020-07-13 21:25:49'),(3,'Acuífero Choapa',4,'2020-07-13 21:26:20','2020-07-13 21:26:20'),(4,'Acuífero Culebrón - Lagunillas',4,'2020-07-13 21:26:52','2020-07-13 21:26:52'),(5,'Acuífero Petorca',5,'2020-07-13 22:28:14','2020-07-13 22:28:14'),(6,'Acuífero La Ligua',5,'2020-07-13 22:36:46','2020-07-13 22:36:46'),(7,'Acuífero Aconcagua',5,'2020-07-13 22:37:02','2020-07-13 22:37:02'),(8,'Acuífero Catapilco',5,'2020-07-13 22:39:15','2020-07-13 22:39:15'),(9,'Acuífero Maipo',13,'2020-07-13 22:40:12','2020-07-13 22:40:12'),(10,'Acuífero Casablanca',5,'2020-07-13 22:40:38','2020-07-13 22:40:38'),(11,'Acuífero Estero Cartagena',5,'2020-07-14 15:54:20','2020-07-14 15:54:20'),(12,'Acuífero Yali',13,'2020-07-14 19:24:00','2020-07-14 19:24:00'),(13,'Cachapoal',6,'2020-07-14 22:39:33','2020-07-14 22:39:33'),(14,'Tinguiririca',6,'2020-07-14 22:39:45','2020-07-14 22:39:45'),(15,'Maule Medio',7,'2020-07-14 22:40:21','2020-07-14 22:40:21'),(16,'Esteros Belco y Arenal',7,'2020-07-14 22:40:39','2020-07-14 22:40:39'),(17,'Cauquenes',7,'2020-07-14 22:40:55','2020-07-14 22:40:55'),(18,'Mataquito',7,'2020-07-14 22:50:15','2020-07-14 22:50:15'),(19,'Alhue',6,'2020-07-15 16:33:20','2020-07-15 16:33:20');
/*!40000 ALTER TABLE `acuiferos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cauces`
--

DROP TABLE IF EXISTS `cauces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cauces` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `region_id` int(11) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cauce_unique` (`region_id`,`nombre`),
  CONSTRAINT `FK_cauces_1` FOREIGN KEY (`region_id`) REFERENCES `regiones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cauces`
--

LOCK TABLES `cauces` WRITE;
/*!40000 ALTER TABLE `cauces` DISABLE KEYS */;
INSERT INTO `cauces` (`id`, `region_id`, `nombre`, `created_at`, `updated_at`) VALUES (1,4,'Río Elqui, Canal Bellavista','2020-07-13 21:15:45','2020-07-13 21:15:45'),(2,4,'Río Cogotí, Canal Ramadas','2020-07-13 21:16:14','2020-07-13 21:16:14'),(3,4,'1ª sección Río Choapa','2020-07-13 21:20:18','2020-07-13 21:20:18'),(4,4,'Río Claro, Paihuano','2020-07-13 21:20:35','2020-07-13 21:20:35'),(5,4,'Río Limarí, Canal Tamelcura','2020-07-13 21:21:26','2020-07-13 21:21:26'),(6,5,'1ª Sección Río Aconcagua, Canal San Rafael','2020-07-14 15:46:23','2020-07-14 15:46:23'),(7,5,'2ª Sección Río Aconcagua','2020-07-14 15:47:02','2020-07-14 15:47:02'),(8,5,'2ª Sección Aconcagua, Canal Las Vegas Molino','2020-07-14 15:47:30','2020-07-14 15:47:30'),(9,5,'3ª Sección Río Aconcagua, Canal Waddington','2020-07-14 15:48:11','2020-07-14 15:48:11'),(10,5,'3ª Sección Río Aconcagua, Canal Candelaria','2020-07-14 15:48:42','2020-07-14 15:48:42'),(11,5,'3ª Sección Río Aconcagua, Canal Mauco','2020-07-14 15:49:16','2020-07-14 15:49:16'),(12,13,'3ª Sección Río Maipo, Canal Chocalán','2020-07-14 19:17:20','2020-07-14 19:17:20'),(13,13,'1ª Sección Río Maipo, Canal Lonquén - Isla','2020-07-14 19:18:00','2020-07-14 19:18:00'),(14,13,'Canal Las Mercedes, María Pinto','2020-07-14 19:19:48','2020-07-14 19:19:48'),(15,13,'3ª Sección Río Maipo, Canal Culipran','2020-07-14 19:20:20','2020-07-14 19:20:20'),(16,6,'Río Cachapoal, Canal La compañia','2020-07-14 23:03:03','2020-07-14 23:03:03'),(17,7,'Río Teno, Canal Merino','2020-07-14 23:03:37','2020-07-14 23:03:37'),(18,6,'Río Cachapoal, Canal El Peumal','2020-07-14 23:05:05','2020-07-14 23:05:05'),(19,6,'Río Tinguiririca, Canal Alto Requehua','2020-07-14 23:05:57','2020-07-14 23:05:57'),(20,6,'Río Tinguiririca, Canal El Tambo','2020-07-14 23:06:28','2020-07-14 23:06:28'),(21,6,'Río Cachapoal','2020-07-14 23:10:53','2020-07-14 23:10:53'),(22,6,'Río Tinguiririca','2020-07-14 23:11:08','2020-07-14 23:11:08'),(23,9,'Río Queule','2020-07-15 15:54:09','2020-07-15 15:54:09'),(24,9,'Río Liucura','2020-07-15 15:54:34','2020-07-15 15:54:34'),(25,14,'Río Reca','2020-07-15 15:55:07','2020-07-15 15:55:07'),(26,14,'Río Leufucade','2020-07-15 15:55:31','2020-07-15 15:55:31');
/*!40000 ALTER TABLE `cauces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuencas`
--

DROP TABLE IF EXISTS `cuencas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuencas` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `region_id` int(11) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cuenca_unique` (`nombre`,`region_id`),
  KEY `FK_cuencass_1` (`region_id`),
  CONSTRAINT `FK_cuencas_1` FOREIGN KEY (`region_id`) REFERENCES `regiones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuencas`
--

LOCK TABLES `cuencas` WRITE;
/*!40000 ALTER TABLE `cuencas` DISABLE KEYS */;
INSERT INTO `cuencas` (`id`, `nombre`, `region_id`, `created_at`, `updated_at`) VALUES (1,'Río Elqui',4,'2020-07-13 21:40:02','2020-07-13 21:40:02'),(2,'Río Limarí',4,'2020-07-13 21:40:14','2020-07-13 21:40:14'),(3,'Río Choapa',4,'2020-07-13 21:41:00','2020-07-13 21:41:00'),(4,'Río Petorca',5,'2020-07-14 16:30:23','2020-07-14 16:30:23'),(5,'Río La Ligua',5,'2020-07-14 16:30:40','2020-07-14 16:30:40'),(6,'Río Aconcagua',5,'2020-07-14 16:30:57','2020-07-14 16:30:57'),(7,'Estero Casablanca',5,'2020-07-14 16:31:58','2020-07-14 16:31:58'),(8,'Costeras La Ligua - Aconcagua',5,'2020-07-14 16:38:57','2020-07-14 16:38:57'),(9,'Costeras Aconcagua - Maipo',5,'2020-07-14 16:54:44','2020-07-14 16:54:44'),(10,'Río Maipo',13,'2020-07-14 19:20:40','2020-07-14 19:20:40'),(11,'Estero Yali',13,'2020-07-14 19:29:14','2020-07-14 19:29:14'),(12,'Río Rapel',6,'2020-07-14 22:24:22','2020-07-14 22:24:22'),(13,'Río Mataquito',7,'2020-07-14 22:27:12','2020-07-14 22:27:12'),(14,'Río Maule',7,'2020-07-14 22:36:41','2020-07-14 22:36:41'),(15,'Río Tinguiririca',6,'2020-07-14 23:11:37','2020-07-14 23:11:37'),(16,'Río Cachapoal',6,'2020-07-14 23:11:52','2020-07-14 23:11:52'),(17,'Río Teno',7,'2020-07-14 23:12:13','2020-07-14 23:12:13'),(18,'Río Queulen',9,'2020-07-15 15:56:08','2020-07-15 15:56:08'),(19,'Río Liucura',9,'2020-07-15 15:56:28','2020-07-15 15:56:28'),(20,'Río Reca',14,'2020-07-15 15:56:57','2020-07-15 15:56:57'),(21,'Río Leufucade',14,'2020-07-15 15:57:16','2020-07-15 15:57:16');
/*!40000 ALTER TABLE `cuencas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `derechos_de_aguas`
--

DROP TABLE IF EXISTS `derechos_de_aguas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `derechos_de_aguas` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `compra_o_venta` int(11) unsigned NOT NULL,
  `region_id` int(11) unsigned NOT NULL,
  `cuenca_id` int(11) unsigned NOT NULL,
  `subterranea_o_superficial` int(11) unsigned NOT NULL,
  `acuifero_id` int(11) unsigned DEFAULT NULL,
  `sector_id` int(11) unsigned DEFAULT NULL,
  `cauce_id` int(11) unsigned DEFAULT NULL,
  `cantidad` double unsigned NOT NULL,
  `volumen_o_accion` int(11) unsigned NOT NULL,
  `latitud` double NOT NULL,
  `longitud` double NOT NULL,
  `continuo_o_discontinuo` int(11) unsigned NOT NULL,
  `permanente_o_eventual` int(11) unsigned NOT NULL,
  `consuntivo_o_no_consuntivo` int(11) unsigned NOT NULL,
  `activo` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_derechos_de_aguas_1` (`region_id`),
  KEY `FK_derechos_de_aguas_2` (`cuenca_id`),
  KEY `FK_derechos_de_aguas_3` (`acuifero_id`),
  KEY `FK_derechos_de_aguas_5` (`cauce_id`),
  KEY `FK_derechos_de_aguas_4` (`sector_id`),
  CONSTRAINT `FK_derechos_de_aguas_1` FOREIGN KEY (`region_id`) REFERENCES `regiones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_derechos_de_aguas_2` FOREIGN KEY (`cuenca_id`) REFERENCES `cuencas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_derechos_de_aguas_3` FOREIGN KEY (`acuifero_id`) REFERENCES `acuiferos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_derechos_de_aguas_4` FOREIGN KEY (`sector_id`) REFERENCES `sectores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_derechos_de_aguas_5` FOREIGN KEY (`cauce_id`) REFERENCES `cauces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `derechos_de_aguas`
--

LOCK TABLES `derechos_de_aguas` WRITE;
/*!40000 ALTER TABLE `derechos_de_aguas` DISABLE KEYS */;
INSERT INTO `derechos_de_aguas` (`id`, `compra_o_venta`, `region_id`, `cuenca_id`, `subterranea_o_superficial`, `acuifero_id`, `sector_id`, `cauce_id`, `cantidad`, `volumen_o_accion`, `latitud`, `longitud`, `continuo_o_discontinuo`, `permanente_o_eventual`, `consuntivo_o_no_consuntivo`, `activo`, `user_id`, `created_at`, `updated_at`) VALUES (1,2,4,1,1,1,1,NULL,13,1,-30.044861631856637,-70.68328857421876,1,1,1,1,1,'2020-07-13 21:42:57','2020-07-13 21:42:57'),(2,2,4,2,1,2,6,NULL,2,1,-30.839129159362248,-71.24633789062501,1,1,1,1,1,'2020-07-13 21:47:22','2020-07-13 21:47:22'),(3,1,4,1,1,1,2,NULL,10,1,-30.05637499541002,-70.52947998046876,1,1,1,1,1,'2020-07-13 21:49:18','2020-07-13 21:49:18'),(4,1,4,1,1,4,3,NULL,5,1,-30.06316416975613,-71.2456512451172,1,1,1,1,1,'2020-07-13 21:56:33','2020-07-13 21:56:33'),(5,1,4,1,1,4,4,NULL,15,1,-29.943395604654192,-71.25595092773439,1,1,1,1,1,'2020-07-13 21:58:29','2020-07-13 21:58:29'),(6,1,4,3,1,3,5,NULL,10,1,-31.815150045897454,-70.89820861816408,1,1,1,1,1,'2020-07-13 21:59:59','2020-07-13 21:59:59'),(7,1,4,3,1,3,8,NULL,10,1,-31.780713277818553,-71.08978271484376,1,1,1,1,1,'2020-07-13 22:03:03','2020-07-13 22:03:03'),(8,2,4,1,2,NULL,NULL,1,10,2,-30.040086388117984,-71.12960815429689,1,1,1,1,1,'2020-07-13 22:12:07','2020-07-13 22:12:07'),(9,2,4,2,2,NULL,NULL,2,40,1,-31.088007585576435,-70.9325408935547,1,2,1,1,1,'2020-07-13 22:15:01','2020-07-13 22:15:01'),(10,1,4,3,2,NULL,NULL,3,10,1,-31.8143396088331,-70.90370178222658,1,1,1,1,1,'2020-07-13 22:15:53','2020-07-13 22:15:53'),(11,1,4,1,2,NULL,NULL,4,15,1,-30.049642724214245,-70.51437377929689,1,1,1,1,1,'2020-07-13 22:16:32','2020-07-13 22:16:32'),(12,1,4,2,2,NULL,NULL,5,30,1,-30.61576524641004,-71.21063232421876,1,1,1,1,1,'2020-07-13 22:17:20','2020-07-13 22:17:20'),(13,2,5,6,1,7,9,NULL,2,1,-32.90427281375658,-71.22985839843751,1,1,1,1,1,'2020-07-14 16:33:45','2020-07-14 16:33:45'),(14,2,5,6,1,7,9,NULL,5,1,-32.848004837582934,-71.24359130859376,1,1,1,1,1,'2020-07-14 16:34:30','2020-07-14 16:34:30'),(15,2,5,7,1,10,19,NULL,5,1,-33.32743594395179,-71.40357971191408,1,1,1,1,1,'2020-07-14 16:36:54','2020-07-14 16:36:54'),(16,2,5,6,1,7,11,NULL,30,1,-33.01212036497868,-71.20651245117189,1,1,1,1,1,'2020-07-14 16:37:53','2020-07-14 16:37:53'),(17,2,5,8,1,8,23,NULL,8,1,-32.57159649074342,-71.27140045166017,1,1,1,1,1,'2020-07-14 16:40:00','2020-07-14 16:40:00'),(18,2,5,4,1,5,13,NULL,3,1,-32.28152684658578,-71.01940155029298,1,1,1,1,1,'2020-07-14 16:41:34','2020-07-14 16:41:34'),(19,2,5,6,2,NULL,NULL,6,3,2,-32.78645399168555,-70.66200256347658,1,1,1,1,1,'2020-07-14 16:45:20','2020-07-14 16:45:20'),(20,2,5,6,2,NULL,NULL,6,27.9,1,-32.78938525707409,-70.6688690185547,1,1,1,1,1,'2020-07-14 16:46:04','2020-07-14 16:46:04'),(21,2,5,6,2,NULL,NULL,7,50,1,-32.80027274847257,-70.94146728515626,1,1,1,1,1,'2020-07-14 16:47:17','2020-07-14 16:47:17'),(22,2,5,6,2,NULL,NULL,9,19,1,-32.80493602594992,-71.18728637695314,1,1,1,1,1,'2020-07-14 16:48:11','2020-07-14 16:48:11'),(23,2,5,6,2,NULL,NULL,8,40,1,-32.84186378608103,-70.96824645996095,1,1,1,1,1,'2020-07-14 16:48:57','2020-07-14 16:48:57'),(24,2,5,6,2,NULL,NULL,10,30,1,-32.89100279831607,-71.25148773193361,1,1,1,1,1,'2020-07-14 16:49:44','2020-07-14 16:49:44'),(25,2,5,6,2,NULL,NULL,11,30,1,-32.82669194338949,-71.24153137207033,1,1,1,1,1,'2020-07-14 16:50:30','2020-07-14 16:50:30'),(26,1,5,6,1,7,12,NULL,80,1,-32.8179314441805,-70.58166503906251,1,1,1,1,1,'2020-07-14 16:52:52','2020-07-14 16:52:52'),(27,2,5,9,1,11,22,NULL,5,1,-33.5496929484415,-71.57953262329103,1,1,1,1,1,'2020-07-14 16:55:49','2020-07-14 16:55:49'),(28,1,5,6,1,7,10,NULL,30,1,-32.83610994681866,-71.08428955078126,1,1,1,1,1,'2020-07-14 16:56:34','2020-07-14 16:56:34'),(29,1,5,6,1,7,17,NULL,24,1,-32.93135639729547,-71.42623901367189,1,1,1,1,1,'2020-07-14 16:58:16','2020-07-14 16:58:16'),(30,1,5,5,1,6,18,NULL,20,1,-32.50976218008824,-71.00875854492189,1,1,1,1,1,'2020-07-14 17:00:11','2020-07-14 17:00:11'),(31,1,5,5,1,6,26,NULL,9,1,-32.429407251711886,-70.92395782470705,1,1,1,1,1,'2020-07-14 17:01:13','2020-07-14 17:01:13'),(32,1,5,4,1,5,14,NULL,30,1,-32.24338229532422,-70.74508666992189,1,1,1,1,1,'2020-07-14 17:03:42','2020-07-14 17:03:42'),(33,1,5,9,1,10,21,NULL,4,1,-33.267761415658526,-71.5917205810547,1,1,1,1,1,'2020-07-14 17:05:29','2020-07-14 17:05:29'),(34,2,13,10,1,9,27,NULL,10,1,-33.28152416408673,-70.87280273437501,1,1,1,1,1,'2020-07-14 19:30:06','2020-07-14 19:30:06'),(35,2,13,10,1,9,28,NULL,30,1,-33.6969238615141,-70.97854614257814,1,1,1,1,2,'2020-07-14 19:30:50','2020-07-14 19:30:50'),(36,2,13,10,1,9,29,NULL,4,1,-33.447080496370084,-70.63110351562501,1,1,1,1,2,'2020-07-14 19:36:25','2020-07-14 19:36:25'),(37,2,13,10,1,9,30,NULL,1,1,-33.37336624734388,-70.87966918945314,1,1,1,1,2,'2020-07-14 19:38:45','2020-07-14 19:38:45'),(38,2,13,10,1,9,31,NULL,15,1,-33.20155038766339,-70.67916870117189,1,1,1,1,2,'2020-07-14 19:39:44','2020-07-14 19:39:44'),(39,2,13,10,1,9,32,NULL,10,1,-33.12050109439071,-70.79933166503908,1,1,1,1,2,'2020-07-14 19:49:39','2020-07-14 19:49:39'),(40,2,13,10,2,NULL,NULL,12,19.7,2,-33.50915693197671,-71.1193084716797,1,1,1,1,2,'2020-07-14 19:50:44','2020-07-14 19:53:38'),(41,2,13,10,2,NULL,NULL,13,1.124,2,-33.74452223800715,-70.81478118896486,1,1,1,1,2,'2020-07-14 19:53:28','2020-07-14 19:53:28'),(42,1,13,10,2,NULL,NULL,14,3,1,-33.51792984803776,-71.08566284179689,1,1,1,1,2,'2020-07-14 20:02:39','2020-07-14 20:02:39'),(43,1,13,10,2,NULL,NULL,15,40,1,-33.797408767572485,-71.23260498046876,1,1,1,1,2,'2020-07-14 20:07:47','2020-07-14 20:07:47'),(44,1,13,11,1,12,33,NULL,5,1,-33.8054001306314,-71.59515380859376,1,1,1,1,2,'2020-07-14 20:16:08','2020-07-14 20:16:08'),(45,1,13,10,1,9,34,NULL,10,1,-33.85017878258423,-70.9102249145508,1,1,1,1,2,'2020-07-14 20:19:00','2020-07-14 20:19:00'),(46,1,13,10,1,9,35,NULL,20,1,-33.51736104016798,-71.13784790039064,1,1,1,1,2,'2020-07-14 20:21:36','2020-07-14 20:21:36'),(47,2,13,10,1,9,29,NULL,54,1,-33.59410198750169,-70.82885742187501,1,1,1,1,2,'2020-07-14 21:35:18','2020-07-14 21:35:18'),(48,2,6,12,1,14,41,NULL,7,1,-34.66913512488528,-71.35620117187501,1,1,1,1,2,'2020-07-14 22:54:51','2020-07-14 22:54:51'),(49,2,7,14,1,15,55,NULL,32,1,-35.878986257117674,-71.55395507812501,1,1,1,1,2,'2020-07-14 22:57:38','2020-07-14 23:20:18'),(50,2,6,16,2,NULL,NULL,16,20,1,-34.29777104914692,-70.92773437500001,1,1,1,1,2,'2020-07-14 23:13:40','2020-07-14 23:13:40'),(51,2,7,17,2,NULL,NULL,17,22,1,-34.9665432522752,-71.19140625000001,1,1,1,1,2,'2020-07-14 23:14:35','2020-07-14 23:14:35'),(52,2,6,16,2,NULL,NULL,18,27,1,-34.313726483845535,-70.83435058593751,1,1,1,1,2,'2020-07-14 23:15:40','2020-07-14 23:15:40'),(53,2,6,15,2,NULL,NULL,19,100,1,-34.42937962405845,-71.09527587890626,1,1,1,1,2,'2020-07-14 23:16:42','2020-07-14 23:16:42'),(54,2,6,15,2,NULL,NULL,20,125,1,-34.440211735663354,-71.07879638671876,1,1,1,1,2,'2020-07-14 23:17:40','2020-07-14 23:17:40'),(55,2,9,19,2,NULL,NULL,24,55,1,-39.071118244867236,-71.60888671875001,1,1,1,1,2,'2020-07-15 16:01:29','2020-07-15 16:01:29'),(56,2,14,21,2,NULL,NULL,26,1900,1,-39.64033546059732,-72.33947753906251,1,1,2,1,2,'2020-07-15 16:04:49','2020-07-15 16:04:49'),(57,2,14,20,2,NULL,NULL,25,1200,1,-39.65945930502412,-72.33398437500001,1,1,2,1,2,'2020-07-15 16:06:08','2020-07-15 16:06:08'),(58,1,6,15,1,14,50,NULL,60,1,-34.695853545363555,-71.02111816406251,1,1,1,1,2,'2020-07-15 16:26:45','2020-07-15 16:26:45'),(59,1,6,15,1,14,49,NULL,60,1,-34.59817275672876,-71.00463867187501,1,1,1,1,2,'2020-07-15 16:27:38','2020-07-15 16:27:38'),(60,1,6,15,1,14,42,NULL,100,1,-34.45632691788964,-71.44958496093751,1,1,1,1,2,'2020-07-15 16:28:38','2020-07-15 16:28:38'),(61,1,6,16,1,13,43,NULL,30,1,-34.18088836160574,-70.70800781250001,1,1,1,1,2,'2020-07-15 16:29:33','2020-07-15 16:29:33'),(62,1,6,12,1,13,48,NULL,50,1,-34.32497336893744,-71.30126953125001,1,1,1,1,2,'2020-07-15 16:30:47','2020-07-15 16:30:47'),(63,1,6,12,1,13,47,NULL,30,1,-34.43177475324417,-71.10076904296876,1,1,1,1,2,'2020-07-15 16:31:30','2020-07-15 16:31:30'),(64,1,6,12,1,19,56,NULL,20,1,-33.87045302953162,-71.42211914062501,1,1,1,1,2,'2020-07-15 16:35:45','2020-07-15 16:35:45'),(65,1,7,14,1,15,51,NULL,70,1,-35.41511063335412,-71.64184570312501,1,1,1,1,2,'2020-07-15 16:39:16','2020-07-15 16:39:16'),(66,1,13,10,1,9,44,NULL,50,1,-33.98431183877377,-70.59265136718751,1,1,1,1,2,'2020-07-15 16:41:11','2020-07-15 16:41:11'),(67,1,13,10,1,9,36,NULL,60,1,-33.82924322474234,-70.71350097656251,1,1,1,1,2,'2020-07-15 16:42:11','2020-07-15 16:42:11'),(68,1,13,10,1,9,39,NULL,30,1,-33.73137972210212,-70.74096679687501,1,1,1,1,2,'2020-07-15 16:42:54','2020-07-15 16:42:54'),(69,1,13,10,1,9,37,NULL,70,1,-33.612250543483434,-70.60569763183595,1,1,1,1,2,'2020-07-15 16:44:27','2020-07-15 16:44:27');
/*!40000 ALTER TABLE `derechos_de_aguas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regiones`
--

DROP TABLE IF EXISTS `regiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regiones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `zona` varchar(45) NOT NULL,
  `orden_prioridad` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `region_unique` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regiones`
--

LOCK TABLES `regiones` WRITE;
/*!40000 ALTER TABLE `regiones` DISABLE KEYS */;
INSERT INTO `regiones` (`id`, `nombre`, `zona`, `orden_prioridad`) VALUES (1,'I de Tarapacá','Norte',2),(2,'II de Antofagasta','Norte',3),(3,'III de Atacama','Norte',4),(4,'IV de Coquimbo','Norte',5),(5,'V de Valparaíso','Centro',6),(6,'VI de O\'Higgins','Centro',8),(7,'VII del Maule','Centro',9),(8,'VIII del Bio Bio','Centro',11),(9,'IX de la Araucanía','Sur',12),(10,'X de los Lagos','Sur',14),(11,'XI de Aysén','Austral',15),(12,'XII de Magallanes y de la Antártica Chilena','Austral',16),(13,'XIII Metropolitana','Centro',7),(14,'XIV de los Ríos','Sur',13),(15,'XV de Arica y Parinacota','Norte',1),(16,'XVI Del Ñuble','Norte',10);
/*!40000 ALTER TABLE `regiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sectores`
--

DROP TABLE IF EXISTS `sectores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sectores` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL DEFAULT '',
  `region_id` int(11) unsigned NOT NULL,
  `acuifero_id` int(11) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sector_unique` (`nombre`,`region_id`) USING BTREE,
  KEY `FK_sectores_1` (`region_id`),
  KEY `FK_sectores_2` (`acuifero_id`),
  CONSTRAINT `FK_sectores_1` FOREIGN KEY (`region_id`) REFERENCES `regiones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_sectores_2` FOREIGN KEY (`acuifero_id`) REFERENCES `acuiferos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sectores`
--

LOCK TABLES `sectores` WRITE;
/*!40000 ALTER TABLE `sectores` DISABLE KEYS */;
INSERT INTO `sectores` (`id`, `nombre`, `region_id`, `acuifero_id`, `created_at`, `updated_at`) VALUES (1,'Sector Elqui Alto',4,1,'2020-07-13 21:27:14','2020-07-13 21:27:14'),(2,'Sector Claro',4,1,'2020-07-13 21:28:30','2020-07-13 21:28:30'),(3,'Sector Culebrón',4,4,'2020-07-13 21:29:21','2020-07-13 21:29:21'),(4,'Sector Peñuelas',4,4,'2020-07-13 21:29:54','2020-07-13 21:29:54'),(5,'Sector Choapa Alto',4,3,'2020-07-13 21:30:17','2020-07-13 21:30:17'),(6,'Sector Punitaqui',4,2,'2020-07-13 21:31:01','2020-07-13 21:31:01'),(7,'Sector Huatulame',4,2,'2020-07-13 21:34:37','2020-07-13 21:34:37'),(8,'Sector Choapa Medio',4,3,'2020-07-13 21:35:52','2020-07-13 21:35:52'),(9,'Sector Quillota',5,7,'2020-07-14 16:21:44','2020-07-14 16:21:44'),(10,'Sector Hijuelas - Nogales',5,7,'2020-07-14 16:22:07','2020-07-14 16:22:07'),(11,'Sector Limache',5,7,'2020-07-14 16:22:25','2020-07-14 16:22:25'),(12,'Sector San Felipe - Los Andes',5,7,'2020-07-14 16:22:47','2020-07-14 16:22:47'),(13,'Sector Petorca Poniente',5,5,'2020-07-14 16:23:25','2020-07-14 16:23:25'),(14,'Sector Río Del Sobrante',5,5,'2020-07-14 16:23:50','2020-07-14 17:03:03'),(15,'Sector Río Pedernal',5,5,'2020-07-14 16:24:52','2020-07-14 16:24:52'),(16,'Sector Petorca Oriente',5,5,'2020-07-14 16:25:31','2020-07-14 16:25:31'),(17,'Sector Aconcagua Desembocadura',5,7,'2020-07-14 16:26:30','2020-07-14 16:26:30'),(18,'Sector Estero Los Angeles',5,6,'2020-07-14 16:27:03','2020-07-14 16:27:03'),(19,'Sector La Vinilla - Casablanca',5,10,'2020-07-14 16:27:27','2020-07-14 16:36:02'),(20,'Sector Lo Ovalle',5,10,'2020-07-14 16:27:42','2020-07-14 16:27:42'),(21,'Sector Estero Casablanca',5,10,'2020-07-14 16:28:15','2020-07-14 16:28:15'),(22,'Sector Estero Cartagena',5,11,'2020-07-14 16:28:58','2020-07-14 16:28:58'),(23,'Sector Estero Catapilco',5,8,'2020-07-14 16:29:35','2020-07-14 16:29:35'),(26,'Sector La Ligua Oriente',5,6,'2020-07-14 17:00:35','2020-07-14 17:00:35'),(27,'Sector Lampa',13,9,'2020-07-14 19:21:49','2020-07-14 19:21:49'),(28,'Sector El Monte Nuevo',13,9,'2020-07-14 19:22:09','2020-07-14 19:22:09'),(29,'Sector Santiago Central',13,9,'2020-07-14 19:22:38','2020-07-14 19:22:38'),(30,'Sector Santiago Norte',13,9,'2020-07-14 19:22:57','2020-07-14 19:22:57'),(31,'Sector Colina Inferior',13,9,'2020-07-14 19:23:16','2020-07-14 19:23:16'),(32,'Sector Chacabuco - Polpaico',13,9,'2020-07-14 19:23:35','2020-07-14 19:23:35'),(33,'Sector Yali Bajo El Prado',13,12,'2020-07-14 19:24:22','2020-07-14 19:24:22'),(34,'Sector Laguna Aculeo',13,9,'2020-07-14 19:24:40','2020-07-14 19:24:40'),(35,'Sector Puangue Medio',13,9,'2020-07-14 19:25:01','2020-07-14 19:25:01'),(36,'Sector Paine',13,9,'2020-07-14 19:25:29','2020-07-14 19:25:29'),(37,'Sector Pirque',13,9,'2020-07-14 19:26:25','2020-07-14 19:26:25'),(38,'Sector Melipilla',13,9,'2020-07-14 19:26:50','2020-07-14 19:26:50'),(39,'Sector Buin',13,9,'2020-07-14 19:27:07','2020-07-14 19:27:07'),(40,'Sector La Higuera',13,9,'2020-07-14 19:27:22','2020-07-14 19:27:22'),(41,'Tinguiririca Superior',6,14,'2020-07-14 22:44:17','2020-07-14 22:44:17'),(42,'Tinguiririca Inferior',6,14,'2020-07-14 22:44:40','2020-07-14 22:44:40'),(43,'Graneros - Rancagua',6,13,'2020-07-14 22:45:38','2020-07-14 22:45:38'),(44,'Maipo - Codegua',13,9,'2020-07-14 22:46:34','2020-07-14 22:46:34'),(45,'Rengo - Rosario - Requinoa',6,13,'2020-07-14 22:46:52','2020-07-14 22:46:52'),(46,'Olivar',6,13,'2020-07-14 22:47:05','2020-07-14 22:47:05'),(47,'Sn.Vicente - Malloa - Pelequen',6,13,'2020-07-14 22:47:28','2020-07-14 22:47:28'),(48,'Peumo - Pichidegua - Las Cabras',6,13,'2020-07-14 22:47:57','2020-07-14 22:47:57'),(49,'San Fernando',6,14,'2020-07-14 22:48:15','2020-07-14 22:48:15'),(50,'Chimbarongo',6,14,'2020-07-14 22:48:29','2020-07-14 22:48:29'),(51,'Maule Medio NOrte',7,15,'2020-07-14 22:49:34','2020-07-14 22:49:34'),(52,'Teno - Lontué',7,18,'2020-07-14 22:50:58','2020-07-14 22:50:58'),(53,'Esteros Belco y Arenal',7,16,'2020-07-14 22:51:23','2020-07-14 22:51:23'),(54,'Cauquenes',7,17,'2020-07-14 22:51:42','2020-07-14 22:51:42'),(55,'Maule Medio Sur',7,15,'2020-07-14 22:56:55','2020-07-14 22:56:55'),(56,'Estero Alhue',6,19,'2020-07-15 16:33:36','2020-07-15 16:33:36');
/*!40000 ALTER TABLE `sectores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(45) NOT NULL,
  `password` varchar(100) NOT NULL,
  `activo` int(11) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `user`, `password`, `activo`, `created_at`, `updated_at`) VALUES (1,'fponce','$2y$10$t2E2Y9wy8shyYPCnfD4AeuNFazL1OAYtAGL/GoXp9Vke5imZKXPLa',1,'2020-07-13 21:18:25',NULL),(2,'fgutierrez','rluAB6dojk9bA',1,'2020-07-13 21:18:25',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'araya_actiagro'
--

--
-- Dumping routines for database 'araya_actiagro'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-05 13:41:54
